## 🚀 Welcome to _In Space with Markiplier_ (Written Edition)

### Summary

This is a **written adaptation** of _In Space with Markiplier_, the choose-your-own-adventure experience created by Markiplier and his team.
This project is **purely a fan-made passion project**—nothing more, nothing less.

If you enjoy this version, please leave a comment and an upvote to show how many people would enjoy the full version of this
## ⚠️ Important Notes (Please Read)
### 🛠 Project Status (Early Release)

This is an **early, unfinished version** of the project.
At the moment:
- All **Part 1 choices and endings are fully connected** and navigable.
- The **opening video and first decision path** have been fully written and formatted.
- Most other sections currently contain **structure and links only** (placeholders without full text).

This version is being shared early to:
- Test navigation and overall experience
- See if people enjoy the concept
- Gather feedback before continuing full transcription

Updates will be released as more scenes are written and polished.

If you encounter broken links, formatting issues, or have suggestions, feedback is greatly appreciated.
### Spoiler Warning

- **Strongly recommended:** Do _not_ read this unless you have achieved **at least one ending** in the original experience.
- This project **does not replace** the original and cannot fully capture the effort, creativity, or love put into it by Mark and his team.
- By continuing, you’re assumed to be okay with:
1. Spoilers
2. Minor changes or adaptations
3. Or both
(If not—go play the original first. Seriously. It’s worth it.)
### 📘 Formatting & Intended Use
- This project is designed **specifically for Obsidian.md**.
- It _can_ be used in other text editors or viewers, but the experience will be limited.
- For the best experience, use Obsidian (it’s free—what could possibly go wrong?).
### 🔗 Links & Backlinks
- In Obsidian, you’ll see **purple links** throughout the text. These act like the clickable choices in the original adventure.
- Links will point to:
    - Choices you must pick at the end of the episode
    - Characters and their information when they appear for the first time in an episode
- If you notice something that _should_ be linked but isn’t, let me know and I’ll update it.
- If you’re using another text viewer, links will appear with two brackets like this:  
    `[[Welcome Card]]`
    In which case, just navigate manually to the file with that name.

---
### 🗣 Dialogue & Naming

- Dialogue and character names are written **to the best of my ability**.
- If a character has a confirmed canon name that I missed, I’ll update it.
- Otherwise, generic names may be used (e.g., _Pilot_, _Crew Member_).

---
### 🎭 Stage Directions & Actions

- This is **not a full script transcription**.
- Traditional stage directions were avoided to keep the workload reasonable.
- Actions and descriptions are only included when they:
    - Help the story make sense in text form
    - Replace missing visual/audio cues
    - Preserve comedic timing or important moments

---
### 📝 Text Styling Notes

- **Blue, bold text** in Obsidian indicates:
    - Dialogue directions (e.g., who is speaking, tone changes)
    - Important stage directions needed due to lack of visuals
- In non-Obsidian viewers, these will appear as text between two asterisks (`**like this**`).
---

### 🔢 Repeated Video Titles

- Some choices in the original share the same name (e.g., _Wake the Crew_, _Fix It from the Outside_).
- These have been **have been alternately titled to differentiate the notes** (i.e., *Wake the Colonists - Gunther* and *Wake the Colonists - Celci*; *Fix it from the Outside - ADS* and *Fix It from the Outside - Cryo*).
- This has been done to avoid unintentional crossing and is done in a way to attempt to avoid confusion and spoilage.

---
### 👥 Character Sheets

- Character profiles exist for named characters or those with potential recurring roles.
- Information is based on what can be reasonably inferred.
- If you notice missing or incorrect details, let me know and I’ll expand them.

---
### 🎬 Original Content Credits

- Each section includes a link to the **original video** for direct access.
- Please support the original project—it’s the definitive experience.

---
## ▶️ Begin the Adventure

If you’re using Obsidian, click the link below to start.  
Otherwise, navigate to the corresponding file manually:

[[In Space with Markiplier - Part 1]]