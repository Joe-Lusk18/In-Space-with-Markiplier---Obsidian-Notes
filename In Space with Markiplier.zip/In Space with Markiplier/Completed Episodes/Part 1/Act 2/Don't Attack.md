What do you do?
Choice 1: [[We Don't Need Your Help]]
Choice 2: [[We Need Your Help]]