What do you do?
Choice 1: [[Open the Door - Ship|Open the Door]]
Choice 2: [[Don't Open the Door - Ship|Don't Open the Door]]