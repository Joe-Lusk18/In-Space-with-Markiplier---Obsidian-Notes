What do you do?
Choice 1: [[Plan K]]
Choice 2: [[Use the Device]]