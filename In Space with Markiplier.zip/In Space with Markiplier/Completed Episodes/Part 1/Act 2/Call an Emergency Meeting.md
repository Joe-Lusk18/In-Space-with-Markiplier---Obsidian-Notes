What do you do?
Choice 1: [[Pop 'er in Reverse!]]
Choice 2: [[Send a Distress Signal - Wug|Send a Distress Signal]]