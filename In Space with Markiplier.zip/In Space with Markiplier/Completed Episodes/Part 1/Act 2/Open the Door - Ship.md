What do you do?
Choice 1: [[Open the Door - Wug|Open the Door]]
Choice 2: [[Don't Open the Door - Wug|Don't Open the Door]]