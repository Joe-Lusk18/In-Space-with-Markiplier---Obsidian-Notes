What do you do?
Choice 1: [[Attack]]
Choice 2: [[Don't Attack]]