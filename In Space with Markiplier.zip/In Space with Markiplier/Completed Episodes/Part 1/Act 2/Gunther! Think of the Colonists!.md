What do you do?
Choice 1: [[Blow IT up before IT blows YOU up! - Bandit|Blow IT up before IT blows YOU up!]]
Choice 2: [[Burt! Think of the Colonists!]]