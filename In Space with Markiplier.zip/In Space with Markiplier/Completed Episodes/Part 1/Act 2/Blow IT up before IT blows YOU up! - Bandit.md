What do you do?
Choice 1: [[We've Been Here Before]]
Choice 2: [[We've Never Been Here]]