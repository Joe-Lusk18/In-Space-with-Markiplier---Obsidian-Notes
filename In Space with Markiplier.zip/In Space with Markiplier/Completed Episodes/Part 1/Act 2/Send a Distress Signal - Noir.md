What do you do?
Choice 1: [[Give Mark 'The Signal']]
Choice 2: [[Throw Down Your Weapons]]