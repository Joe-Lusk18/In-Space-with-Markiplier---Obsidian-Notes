What do you do?
Choice 1: [[I'm Ready]]
Choice 2: [[Hold on a second...]]