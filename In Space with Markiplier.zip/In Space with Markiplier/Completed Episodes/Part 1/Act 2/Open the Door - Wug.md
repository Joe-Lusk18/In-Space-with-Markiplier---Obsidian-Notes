What do you do?
Choice 1: [[Open the Door - USA|Open the Door]]
Choice 2: [[Don't Open the Door - USA|Don't Open the Door]]