What do you do?
Choice 1: [[Call an Emergency Meeting]]
Choice 2: [[Jump in Again! - Planet|Jump in Again!]]