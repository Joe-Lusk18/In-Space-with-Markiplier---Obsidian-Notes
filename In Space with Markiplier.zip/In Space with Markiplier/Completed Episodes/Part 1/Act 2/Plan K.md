What do you do?
Choice 1: [[Well Now I'm Not Doing It!]]
Choice 2: [[Step in the Wormhole]]