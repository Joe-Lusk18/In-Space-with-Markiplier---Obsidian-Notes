### Ending: Old Man Mark
You have reached an ending. This timeline has now ended
Another timeline awaits you...
- [[In Space with Markiplier - Part 2]]