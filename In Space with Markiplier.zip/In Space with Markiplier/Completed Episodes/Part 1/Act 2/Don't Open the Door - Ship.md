What do you do?
Choice 1: [[Gunther! Think of the Colonists!]]
Choice 2: [[Call for Backup - Wug|Call for Backup]]