What do you do?
Choice 1: [[Fire All Weapons At The Wormhole]]
Choice 2: [[Send a Distress Signal - Noir|Send a Distress Signal]]