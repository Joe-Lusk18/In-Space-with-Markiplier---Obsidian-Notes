Video:
![](https://www.youtube.com/watch?v=raIqPgW-quI)

**Alarm blaring. You run to the back of the command center to grab the fire extinguisher. You put out the fire on the control panel**

[[Computer]] - Alert. Fire extinguished. Warning. Oxygen levels dropping to unsafe levels.

**You run to the door to fix the oxygen, but the lack of oxygen hits you. Your vision becomes blurry and shaky, the whole room spinning. Alarms blare, and every noise is now faint.**

Computer - Warning. Oxygen nearly depleted.

**You make it to Life Support, but you fall down and everything goes black.

**You go back through the wormhole. You are now back in your Cryo-pod**

Cryo Computer - Software update complete

Computer - Good morning Captain. We are currently ERROR years into our journey. Coffee is en route

**You look around confused. You look at your hands wondering what happened. A small jolt of electricity passes between your fingers**

Computer - Current ship status is... absolutely catostrophic. 

**Cryo-Pod lights all turn red. Alarms blare.** 

Computer - Initializing emergency Wakey-Wakey Protocol.

**You are thrown out of your Cryo-Pod. You look out the window, still confused. An explosion is heard in the distance.**

Computer - Reviving Head Engineer

**Mark is thrown out of his Cryo-Pod

[[Mark]] - Captain what the hell is going on??

**You grab Mark's hand and grab the control panel for support. The window shatters and you are holding on, preventing yourselves from being ejected.**

Computer - Hull breach detected. Sealing bulkhead.

**The blast doors close. You let go of Mark's hand.

Mark - **Out of breath and confused** Thank you? Um, what's happening?

**The control panel ignites on fire**

Computer - Fire on the bridge. Error. Automatic Fire Suppression System offline. 

**You run to get the fire extinguisher**

Computer - Error. Life support systems failing.

Mark - I'll get life support.

Computer - Error. Backup systems offline. Fail-safes offline

**You use the fire extinguisher and extinguish the fire.**

Computer - Alert. Fire extinguished

Mark's Voice - **From behind, quietly** Captain?

**You turn around and everything changes. The surroundings are dark, everything is quiet. There are papers and notes everywhere. You follow the signs and approach your Cryo-Pod. The signs on it all say "sleepy-head". As you look at the pod, two bright blue lights where eyes would be open and look at you. A hand is pressed against the pod. Everything begins to shake. You blink and everything is back to normal**

Computer - Alert. Oxygen levels rising.

**The command center door opens and you turn around to see Mark has come back**

Mark - Ah, Captain. There you are. I got life support back online, and I still don't know what the hell is happening, but we seem to have this situation all under control

**The ship jolts, throwing you and Mark backward. The lights start flashing red and the alarm starts blaring**

Computer - Impact detected

Mark - Computer, activate the Asteroid Defense System!

Computer - Analyzing. No

Mark - What do you mean, no?

**The ship jolts again**

Mark - Computer what's wrong with the ADS?

Computer - ADS offline.

Mark - Why?!

Computer - Offline.

Mark - Computer, what is wrong with --

Computer - Offline.

Mark - **Pausing to avoid getting interrupted. Now angry** Computer what's wrong with the ADS?

**Ship jolts again**

Computer - ADS is offline

**You both run down the hallway to the ADS control room

Mark - This doesn't make any sense. We got asteroids hitting the ship and our guns aren't shooting them down.

**Ship jolts again**

Mark - **At the ADS control room door** Thankfully they're still guns so, you know, we should just be able to point and shoot ... them

**You see two turrets aimed right at Mark. The computer screen says "TERMINATE"**

Computer - The Asteroid Defense System is offline. 

**The turrets begin blasting at you. You close the door and move out of the line of fire**

Mark - Well, that's new. Something's gone wrong with the computer. The drones shouldn't be able to attack the crew. I programmed them myself. All right, I know that's not a guarantee, but something's clearly changed.

**Ship jolts again**

Mark - We got to fix the ADS or we're going to get blasted to bits. Just like old times, eh Captain? Pretty much exactly like old times, actually. I think this is what happened to the first Invincible, but they didn't have you! I know you got a plan to save us cooking up in that big brain of yours. I can see the wheels turning. You've faced the odds and beaten them a thousand times before. This is going to be a cakewalk. I'm practically salivating at the thought of how you're going to save us. Come on. Tell me.

What do you do?
Choice 1: [[Send Mark In]]
Choice 2: [[Wake the Crew - Gunther.|Wake The Crew]]
Choice 3: [[Fix it from the Outside! - ADS|Fix it from the Outside!]]