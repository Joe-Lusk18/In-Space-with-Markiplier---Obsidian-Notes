What do you do?
Choice 1: [[Go Towards the Light]]