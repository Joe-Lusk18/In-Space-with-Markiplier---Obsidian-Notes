Original Video:
![](https://www.youtube.com/watch?v=j64oZLF443g)

**Title Sequence**
[[Pilot]] - **To You** You might wanna take a step back there Captain. I'm sorry. I know I'm staring a lot. Huge fan. Huge fan. Been following your career for quite a while now. **To main ship** Visual tower, this is Shuttle Marmota approaching docking bay four. Closing the blast shields.

Visual Tower - Shuttle Marmota, you're clear to dock

Pilot - Copy you. **To You** Truth be told we couldn't afford to show that anyway, but yeah, don't get me wrong. I know exactly where we're heading. Check it out. We're gonna land in five -

**Ship docks aggressively, throws you and Pilot back. Alarm starts blaring**

Pilot - Captain, we're here early. I gotta say, it's an honor. I was thinking maybe we could hang out or something? Go get a coffee. But, you know, beer's cool.

**Door opens and Mark is standing in front of you. Crewmembers are frantically carrying other crewmembers and scanning ship as alarms are still blaring**

[[Mark]] - **Ignoring the chaos around him** Welcome aboard the Invincible II, Captain. Glad to have you here. Took you long enough. But let me give you the grand tour before we embark. This is my pride and joy. My baby. Well, your baby, I guess now. But I made her, and a baby will always remember her father.

**You and Mark enter an elevator**

[[Computer]] - Bio-scan. Welcome aboard, Captain, and head engineer. Prepare for sterilization.

**A blinding light flashes. You and Mark exit elevator**

Mark - First stop, the warp core, the heart and soul of the ship. Still not 100% sure how it works, but you don't need to know how something works in order to use it. And when we found it again, it passed every safety test with flying colors.

**You both begin walking down a hallway**

Mark - It's not gonna be like last time. Oh, no. This time, the Invincible is finally gonna live up to her name. But just in case, I built in a special precaution. If anything goes wrong, we can detonate these explosives and separate the warp core from the rest of the ship. I've yet to meet a problem that can't be solved with explosives. And speaking of explosives, the main reactor!

**You walk into the reactor room**

Mark - Turns out you pretty much need the power of a star to tear open a wormhole, so a star I built. Built like a tank, too.

**Mark taps control panel. The panel starts fritzing. A worker closes blast door**

[[Burt]] - Captain. Burt

Mark - Yea that's Burt. He makes sure that the ship don't go boom. Next up is Cryo.

**Crewmember walks out of Cryo room badly wounded**

[[Crewmember 1]]] - Hey Mark

Mark - Oh, hey. **To you** The colonists are prepped, stable, and ready for transit. Systems are working at 110% too, which is a little weird but overkill never hurts. Trust me. You do not wanna be awake when the warp core hits the gas

Woman - **Down long hallway full of cryogenic pods** Hello? I think I'm supposed to be asleep, but I don't think I am.

**Shield doors close. You turn towards Mark again**

Mark - **With disgust, to Celci** CC

[[Celci]] - **With disdain, to Mark** Asshat. **To you** Captain, all colonists are prepped and stable. 100,000 souls ready for a new life. Let's get them there safe.

Mark - **To Celci, taunting her** Oh don't worry. Before they know it they're gonna wake up to the sight of a brand new planet. With a fresh cup of coffee in their hands.

Celci - **To Mark, angrily** Why don't you give them more windows to look through?

Mark - **Angrily** Well maybe I will! Maybe then someone might appreciate the aesthetics. Besides, **To you** What could go wrong with a crew like this?

**You and Mark walk down hallway**

[[Gunther]] - ADS is good to go. Don't worry, Captain. No asteroid's getting by me. You can count on that.

**As you walk, you hear chatter from the crewmembers talking about you**

[[Crewmember 2]] - **To you** Oh no Captain, I'm falling. Catch me!

**You do not catch him. He falls**

[[Crewmember 3]] - Navigation is online, Captain.

[[Mack (AKA Theory Crew)|Mack]] - Engines are looking good, Captain.

Mark - Life support is online, unless it's not, and then we wouldn't know until we passed out. Seems fine. Everything is accounted for. We're ready to see our new home. All that's left now...

**Mark gestures towards command center door. You enter. Crew members are standing behind the control panel raising a glass at you**

Mark - **Somehow inside despite you walking in first** ... is for you to say the word. **He hands you a glass of champagne** Try not to get them too excited, Captain. I know how your speeches can get people riled up.

**You look at crewmembers. They look back at you, their glasses still raised. Awkward silence ensues. Coughs can be heard. Chica is having the time of her life.**

Computer - Warp core engaged

**Alarms start blaring again. Crewmembers leave command center**

Computer - Wormhole opening in 30 seconds. All personnel report to your assigned Cryo-Pod.

Mark - **Chugs his champagne** Ah, it's alright, Captain. I'm sure you'll make a great speech once we get there.

**He Takes your champagne and chugs it too. He points to your Cryo-Pod**

Mark - **As he's getting in his pod** Oh, and I forgot to mention, it's not a problem of course, but just before you go to sleep, be absolutely sure, do not --

**Cryo-Pod doors close before he can finish talking**

Computer - Wormhole opening in ten, nine, eight, seven, six **You begin to pass out** -- Error **You wake back up** Error. Err- erro- error, error er- err- error. 

**You are trying to open the door as hard as you can**

Computer - Wormhole opening in three, two --

Cryo Computer - A software update is available. Would you like to restart to apply this update?

**Wormhole opens. Overlapping voices can be heard as you move through the wormhole. Everything goes black

Mysterious Voice - Don't give up

**You go back through the wormhole. You wake back up in the Cryo-Pod**

Voice - Software update complete

Computer - Good morning, Captain. We are currently ERROR years into our journey. Coffee is en route. Current ship status is... absolutely catastrophic. 

**Your Cryo-Pod's lights all turn red**

Computer - Initializing emergency Wakey-Wakey Protocol.

**Alarms are blaring. You are forcefully thrown out of your Cryo-Pod

Computer - Reviving Head Engineer

**Mark is thrown even harder out of his Cryo-Pod**

Mark - Captain, what the hell is-- **Window breaks and Mark is ejected from the ship** AHHH

Computer - Hull breach detected. Sealing bulkhead. **Blast door closes, sealing the broken window.** Fire on the bridge. **Control panel lights on fire** Error. Life support systems failing. Error. Automatic Fire Suppression System offline. Error. Fail-safes offline. 

What do you do?
Choice 1: [[Put Out The Fire]]
Choice 2: [[Fix Life Support]]

