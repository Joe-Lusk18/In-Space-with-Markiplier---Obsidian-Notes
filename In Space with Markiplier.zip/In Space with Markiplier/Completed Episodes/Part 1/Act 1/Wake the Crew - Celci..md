What do you do?
Choice 1: [[Wake the Crew - Burt.|Wake the Crew]]
Choice 2: [[Fix it from the Outside! - Nothing|Fix it from the Outside]]