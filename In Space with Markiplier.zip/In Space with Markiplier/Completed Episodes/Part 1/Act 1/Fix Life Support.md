Video:
![](https://www.youtube.com/watch?v=mGtFUm-sgh4)
**Alarms blaring. You run down the hallway to Life Support**

[[Computer]] - Warning. No atmosphere detected within Life Support

**You enter Life Support**

Computer - Warning. Oxygen levels dropping to unsafe levels.

**You read the instructions on the terminal:
`"WARNING: OXYGEN RECYCLING SYSTEMS COMPROMISED. PLEASE MANUALLY ENGAGE BACK-UP SYSTEMS."
You look at the back wall and see three valves labeled "O2 Backup". As you work, the lack of oxygen affects your vision, You rotate the valves.**

Computer - Oxygen levels rising.

**O2 powers back on**

Computer - Good new Captain. The momentary lapse in oxygen extinguished the fire on the bridge. Warning. Brace for impact. 

**An explosion occurs. Alarms begin blaring again.**

Computer - Alert. Hull breach detected. **Voice begins to slur and pitch down** Asteroid Defense System is offline. 

**You run back down the hall towards the ADS room**

Computer - Disregard previous statement Captain. The Asteroid Defense System is working at 100% efficiency. Any vibrations you are feeling are simply the guns working to keep you safe. 

**You open the door to the ADS and see two turrets aimed right at you. The computer screen says "TERMINATE"**

Computer - I said the Asteroid Defense System is... fine. 

**The turrets begin blasting at you. You close the door and move out of the line of fire**

Computer - Captain, please make your way to the nearest bunker and have a nap

What do you do?
Choice 1: [[Wear a Disguise]]
Choice 2: [[Wake the Crew - Gunther|Wake the Crew]]