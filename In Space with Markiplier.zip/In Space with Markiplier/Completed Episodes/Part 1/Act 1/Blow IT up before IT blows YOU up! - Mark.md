What do you do?
Choice 1: [[I Believe You]]
Choice 2: [[This Must be a Dream!]]