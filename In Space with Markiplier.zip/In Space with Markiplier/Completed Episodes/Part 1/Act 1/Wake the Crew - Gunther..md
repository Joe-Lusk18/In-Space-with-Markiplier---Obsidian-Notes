What do you do?
Choice 1: [[Wake the Crew - Celci.|Wake the Crew]]
Choice 2: [[Fix it from the Outside! - Cryo|Fix it from the Outside]]
